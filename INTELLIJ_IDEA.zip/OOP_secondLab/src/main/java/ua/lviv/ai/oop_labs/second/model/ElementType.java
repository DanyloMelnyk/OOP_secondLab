package ua.lviv.ai.oop_labs.second.model;

public enum ElementType {
    IC,
    TRANSISTOR,
    DIODE,
    LED,
    CONDENSER,
    RESISTOR,
    FUSE,
    QUARTZ_RESONATOR
}
